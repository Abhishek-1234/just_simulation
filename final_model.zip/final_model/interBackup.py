# WIFI scenario
import random
import copy
import math
import collections
import dsatur
import csv

maxSimulationTime = 100000 # milliseconds
C = 3 * pow(10, 8) # speed of light m/s
L = 1500	# length of packet in bytes
R = 2 * pow(10, 6) # transmission speed in bps
A = 7
max_collision_constant = 7
channels_list = [1,6,11]
AllAPList = {}
AllSTAList = {}
results = {"default":[], "random":[], "dsatur1":[], "dsatur2":[]}

def euclideanDistance(x1, y1, x2, y2):
	return math.sqrt((x1 - x2)*(x1 - x2) + (y1 - y2)*(y1 - y2))

class AP:
	# transmisison radii
	# ssid
	# associated STAs
	# associated channel number
	# location x, y
	# interferring APs/Channels
	# transmission queue contain only one packet at a time
	def __init__(self, id, x, y, txRadii):
		self.id = id
		self.x = x
		self.y = y
		self.txRadii = txRadii
		self.channel = Channel(1, self)
		self.STAList = []
		self.InterAPList = []
		self.InterChList = []
		self.STAsAffectedbyAP = []
		self.txQ = None
		self.sent_success = 0
		self.sent_fail = 0
		self.retrans = 0
		self.collision = 0
		self.general_collision = 0

	def setChannelNum(self, channel_num):
		self.channel.ch_num = channel_num

	def txRadii(self, txRadii):
		self.txRadii = txRadii

	def setNewChannel(self, ch_num):
		self.channel = Channel(ch_num, self)

	def generate_queue(self, A, index, time = None):
		if time != None:
			arrival_time_sum = time + get_exponential_random_variable(A)
		else:
			arrival_time_sum = self.channel.end_sim_time + get_exponential_random_variable(A)
			
		if arrival_time_sum > maxSimulationTime:
			self.txQ = None
			return
		packet = [arrival_time_sum, self.STAList[index]]
		self.txQ = packet

	def exponential_backoff_time(self, colli):  # will be used mainly for contention time
		rand_num = random.random() * (pow(2, colli) - 1)
		return rand_num * (512/float(R) * pow(10,3))  # 512 bit-times

class STA:
	# Station id
	# associated AP/Channel
	# interferring APs that might not be visible to associated AP
	def __init__(self, id, AP, x, y):
		self.id = id
		self.AP = AP
		self.x = x
		self.y = y
		self.InterAPList = []
		self.InterChList = []


class Channel:
	# channel number
	# associated AP
	# current simulation time
	def __init__(self, ch_num, AP_obj):
		self.ch_num = ch_num
		self.end_sim_time = 0
		self.AP_ID = AP_obj


def get_exponential_random_variable(param):
    # Get random value between 0 (exclusive) and 1 (inclusive)
    uniform_random_value = 1 - random.uniform(0, 1)
    exponential_random_value = (-math.log(1 - uniform_random_value) / float(param))
    return exponential_random_value

def RunSim(n):
	Xaxis = 200
	Yaxis = 200
	radii = 50
	nAPs = n
	nSTAs = 2

	#create APs in certain area of 200m * 200m
	for _ in range(nAPs):
		APnode = AP(_, random.random()*Xaxis, random.random()*Yaxis, radii)
		AllAPList[_] = APnode

	#create STAs in certain area of 200m * 200m
	for i in range(nAPs):
		for j in range(nSTAs):
			nodeId = i * nSTAs + j
			# random angle
			alpha = 2 * math.pi * random.random()
			# random radius
			r = AllAPList[i].txRadii * math.sqrt(random.random())
			# calculating coordinates
			x = abs(r * math.cos(alpha) + AllAPList[i].x)
			y = abs(r * math.sin(alpha) + AllAPList[i].y)
			STAnode = STA(nodeId, AllAPList[i], x, y)
			AllSTAList[nodeId] = STAnode
			AllAPList[i].STAList.append(STAnode)

	def createNecessaryInfo():
		for accessPoint in AllAPList.values():
			accessPoint.InterAPList.clear()
			accessPoint.InterChList.clear()
			accessPoint.sent_success = 0
			accessPoint.retrans = 0
			accessPoint.sent_fail = 0

		for station in AllSTAList.values():
			station.InterAPList.clear()
			station.InterChList.clear()

		# find all APs interfering each other
		for xAccessPoint in AllAPList.values():
			for yAccessPoint in AllAPList.values():
				if xAccessPoint.id == yAccessPoint.id:
					continue
				if euclideanDistance(xAccessPoint.x, xAccessPoint.y, yAccessPoint.x, yAccessPoint.y) <= yAccessPoint.txRadii and xAccessPoint.channel.ch_num == yAccessPoint.channel.ch_num:
					xAccessPoint.InterAPList.append(yAccessPoint)

		# find all interfering channel for each STAs
		for station in AllSTAList.values():
			for accessPoint in AllAPList.values():
				if accessPoint.id == station.AP.id:
					continue
				if euclideanDistance(station.x, station.y, accessPoint.x, accessPoint.y) <= accessPoint.txRadii and station.AP.channel.ch_num == accessPoint.channel.ch_num:
					station.InterAPList.append(accessPoint)
					station.InterChList.append(accessPoint.channel)
					accessPoint.STAsAffectedbyAP.append(station)

	
	
	def printAPSTADetails():
		for accessPoint in AllAPList.values():
			print("AP: ", accessPoint.id, "LOC = ", accessPoint.x, " ", accessPoint.y, "Channel No. = ", accessPoint.channel.ch_num)
			for station in accessPoint.STAList:
				print("\t\tSTA_ID = ", station.id, "LOC = ", station.x, " ", station.y)

		for station in AllSTAList.values():
			print("STA_ID = ", station.id, end = " --> ")
			for intAP in station.InterAPList:
				print(intAP.id, end = " ")
			print()

		for accessPoint in AllAPList.values():
			print("AP: ", accessPoint.id, " Packet: ", accessPoint.txQ[0], " dest: ", accessPoint.txQ[1].id)	

	def schedule(algo):
		packet_dropped = 0
		successful_trans_packet = 0	# in down-link traffic
		total_trans_packets = 0
		retransmitted_packets = 0
		curTime = -1
		
		while True:
			min_node = AP(-1,-1,-1,-1)  # Some random temporary node
			min_node.txQ = [float(math.inf), STA(-1,-1,-1,-1)]
			for accessPoint in AllAPList.values():
				if accessPoint.txQ is not None:
					min_node = min_node if min_node.txQ[0] < accessPoint.txQ[0] else accessPoint

			curTime = min_node.txQ[0]	# update simulation curTime
			if curTime > maxSimulationTime:
				break

			senseBusy = False
			# channel access mechanism
			#sensing_at_same_time = [x for x in min_node.InterAPList if x.txQ != None and x.txQ[0] == min_node.txQ[0]]
			for neighborAP in min_node.InterAPList:
				if neighborAP.id != min_node.id and neighborAP.txQ != None and neighborAP.txQ[0] == min_node.txQ[0]:
					if neighborAP.general_collision < max_collision_constant:
						neighborAP.general_collision += 1
						neighborAP.txQ[0] += neighborAP.exponential_backoff_time(neighborAP.general_collision)
					else:
						# drop the packet and put new packet in the queue
						random_index = random.randint (0, len (neighborAP.STAList)- 1)
						neighborAP.generate_queue(A, random_index, curTime)
						neighborAP.general_collision = 0
						packet_dropped += 1
					senseBusy = True
					
			# if some other AP is transmitting and min_node AP tries to listen
			for neighborAP in min_node.InterAPList:				
				if neighborAP.channel.end_sim_time >= min_node.txQ[0]:
					senseBusy = True
					break
			
			if senseBusy == True:
				if min_node.general_collision < max_collision_constant:
					min_node.general_collision += 1
					min_node.txQ[0] += min_node.exponential_backoff_time(min_node.general_collision)
				else:
					# drop the packet and put new packet in the queue
					random_index = random.randint (0, len (min_node.STAList)- 1)
					min_node.generate_queue(A, random_index, curTime)
					min_node.general_collision = 0
					packet_dropped += 1
				continue

			destinationSTA = min_node.txQ[1]
			min_node.channel.end_sim_time = curTime + ((L*8)/float(R))*(pow(10,3))	# milliseconds

			# to check if delivery was successful at the destination STA, we check if any other interfering AP also has to send some packet 
			# before updated min_node.end_sim_time of the channel
			willDrop = False
			for interferingAP in destinationSTA.InterAPList:
				if interferingAP.txQ is None:
					continue
				if interferingAP.txQ[0] < min_node.channel.end_sim_time or min_node.txQ[0] <= interferingAP.channel.end_sim_time:
					willDrop = True


			# to check if my transmission will destroy packet of some other AP which are not known/reachable to the min_node AP
			for otherAP in AllAPList.values():
				if otherAP.id == min_node.id:
					continue
				
				if otherAP.id in [_.id for _ in min_node.InterAPList]:	# because it will already be handled with channel access mechanism
					continue
				
				if otherAP.txQ == None or otherAP.txQ[0] > min_node.channel.end_sim_time:
					continue

				for disturbedSTA in min_node.STAsAffectedbyAP:
					if disturbedSTA.id == otherAP.txQ[1].id and otherAP.channel.ch_num == min_node.channel.ch_num:
						otherAP.channel.end_sim_time = otherAP.txQ[0] + ((L*8)/float(R))*(pow(10,3))
						if otherAP.collision < max_collision_constant:
							otherAP.collision += 1
							otherAP.retrans += 1
							retransmitted_packets += 1
							otherAP.txQ[0] = otherAP.channel.end_sim_time + otherAP.exponential_backoff_time(otherAP.collision)
						else:
							# drop the packet and put new packet in the queue
							random_index = random.randint (0, len (min_node.STAList)- 1)
							otherAP.generate_queue(A, random_index)
							otherAP.collision = 0
							otherAP.sent_fail += 1
							packet_dropped += 1
						
						total_trans_packets += 1 # for dropped packet of other station
						break

			if willDrop == True:
				if min_node.collision < max_collision_constant:
					min_node.collision += 1
					min_node.retrans += 1
					retransmitted_packets += 1
					min_node.txQ[0] = min_node.channel.end_sim_time + min_node.exponential_backoff_time(min_node.collision)
				else:
					# drop the packet and put new packet in the queue
					random_index = random.randint (0, len (min_node.STAList)- 1)
					min_node.generate_queue(A, random_index)
					min_node.collision = 0
					packet_dropped += 1
					min_node.sent_fail += 1
			else:
				successful_trans_packet += 1
				min_node.sent_success += 1
				random_index = random.randint (0, len (min_node.STAList)- 1)
				min_node.generate_queue(A, random_index)
			
			total_trans_packets += 1

		print("Total transmitted packet = ", total_trans_packets)
		print("Successful Packet = ", successful_trans_packet)
		print("Dropped Packet = ", packet_dropped)
		print("Retransmitted Packets = ", retransmitted_packets)
		efficiency = successful_trans_packet/float(total_trans_packets)
		print("Efficiency = ", efficiency)
		throughput = ((L * successful_trans_packet * 8) / (float(maxSimulationTime) * pow(10, -3)) * pow(10, -6))
		print("Throughput = ", throughput, "Mbps")
		avg_throughput = throughput/nAPs
		print("AVG. Throughput = ", avg_throughput, "Mbps")
		print("----------------------------------------------------------------------------------------------------------")	
		results[algo].append([total_trans_packets, successful_trans_packet, packet_dropped, retransmitted_packets, efficiency, throughput, avg_throughput])

	# generate one packet for each AP
	for accessPoint in AllAPList.values():
		random_index = random.randint (0, len (accessPoint.STAList)- 1)
		accessPoint.generate_queue(A, random_index)

	createNecessaryInfo()
	# creating interference_graph from topology for applying Dsatur in further study
	interference_graph = {}
	for accessPoint in AllAPList.values():
		neighbours = [x.id for x in accessPoint.InterAPList]
		interference_graph[accessPoint.id] = neighbours

	#printAPSTADetails()
	schedule("default")

	# randomly assigning channel to AP
	for accessPoint in AllAPList.values():
		accessPoint.setNewChannel(channels_list[random.randint(0, len (channels_list) - 1)])

	# generate one packet for each AP
	for accessPoint in AllAPList.values():
		random_index = random.randint (0, len (accessPoint.STAList)- 1)
		accessPoint.generate_queue(A, random_index)
	
	createNecessaryInfo()
	#printAPSTADetails()
	schedule("random")

#########################################################################################################
########################## dsatur on interference graph from AP ########################################
#########################################################################################################
	channel_allocation_result = dsatur.RunDSaturAlgo(interference_graph, channels_list)
	print(channel_allocation_result)
	
	for key, value in channel_allocation_result.items():
		AllAPList[key].setNewChannel(value)

	# generate one packet for each AP
	for accessPoint in AllAPList.values():
		random_index = random.randint (0, len (accessPoint.STAList)- 1)
		accessPoint.generate_queue(A, random_index)
	
	createNecessaryInfo()
	#printAPSTADetails()
	schedule("dsatur1")

#########################################################################################################
########################## dsatur on interference graph from both AP and client #########################
#########################################################################################################
	new_interference_graph = copy.deepcopy(interference_graph)
	for station in AllSTAList.values():
		interferingAPs = [x.id for x in station.InterAPList]
		associatedAP = station.AP
		new_interference_graph[associatedAP.id].extend(interferingAPs)
		new_interference_graph[associatedAP.id] = list(set(new_interference_graph[associatedAP.id]))

	channel_allocation_result = dsatur.RunDSaturAlgo(new_interference_graph, channels_list)
	print(channel_allocation_result)
	
	for key, value in channel_allocation_result.items():
		AllAPList[key].setNewChannel(value)

	# generate one packet for each AP
	for accessPoint in AllAPList.values():
		random_index = random.randint (0, len (accessPoint.STAList)- 1)
		accessPoint.generate_queue(A, random_index)
	
	createNecessaryInfo()
	#printAPSTADetails()
	schedule("dsatur2")

print("wifi without rts/cts")
def findavg(listOfList):
	res = []
	for j in range(len(listOfList[0])):
		avg_val = 0
		for i in range(len(listOfList)):
			avg_val+=listOfList[i][j]
		avg_val/=len(listOfList)
		res.append(avg_val)
	return res

final_result = {"num_of_APs":[], "algo":[], "total_trans_packets":[], "successful_trans_packet":[], "packet_dropped":[], "retransmitted_packets":[], "efficiency":[], "throughput":[], "avg_throughput":[]}
for n in range(5,61,5):
	for _ in range(30):
		RunSim(n)
	
	for k,v in results.items():
		res = findavg(v)
		final_result["num_of_APs"].append(n)
		final_result["algo"].append(k)
		final_result["total_trans_packets"].append(res[0])
		final_result["successful_trans_packet"].append(res[1])
		final_result["packet_dropped"].append(res[2])
		final_result["retransmitted_packets"].append(res[3])
		final_result["efficiency"].append(res[4])
		final_result["throughput"].append(res[5])
		final_result["avg_throughput"].append(res[6])
	
	for v in results.values():
		v.clear()

with open("wifi_result.csv", "w") as outfile:
	writer = csv.writer(outfile)
	writer.writerow(final_result.keys())
	writer.writerows(zip(*final_result.values()))