from math import sqrt, inf
from random import choice
import sys

class Vertex:

    def __init__(self, id):
        self.id = id
        self.neighbours = []
        self.color = None
        self.saturation = 0

    def get_degree(self):
        return len(self.neighbours)

    def __lt__(self, other):
        return self.get_degree() < other.get_degree()

    def __str__(self):
        return str(self.id) + " | degree: " + str(self.get_degree()) + \
                " | saturation: " + str(self.saturation) + " | color: " + str(self.color)


class Graph:

    def __init__(self, vertex_list):
        self.vertex_list = vertex_list

    def get_statistics(self):
        ordered_vertexes = sorted(self.vertex_list)

        min_degree = ordered_vertexes[0].get_degree()
        max_degree = ordered_vertexes[-1].get_degree()

        degree_list = [vertex.get_degree() for vertex in ordered_vertexes]

        medium_degree = sum(degree_list) / len(degree_list)

        sd_degree = sqrt(sum([(degree - medium_degree)**2 for degree in degree_list]) / len(degree_list))

        return min_degree, max_degree, medium_degree, sd_degree


    @staticmethod
    def add_edges(v, u):
        if v not in u.neighbours:
            v.neighbours.append(u)
            u.neighbours.append(v)

class Color:
    color_names = []
    next_id = 0

    def __init__(self):
        self.id = Color.next_id
        Color.next_id += 1
        self.name = Color.color_names[self.id]
        self.count = 0

    def __lt__(self, other):
        return self.count < other.count

    def __str__(self):
        return "[" + str(self.id) + " | count: " + str(self.count) + "]"

def Dsatur(g):
    colors = []

    for v in g.vertex_list:
        v.color = None

    random_v = get_next_dsatur_vertex(g)
    paint_vertex(random_v, colors)

    for u in random_v.neighbours:
        if u.color == None:
            u.saturation += 1

    new_v = get_next_dsatur_vertex(g)
    
    while (new_v != None):
        paint_vertex(new_v, colors)

        for u in new_v.neighbours:
            if u.color == None:
                u.saturation += 1

        new_v = get_next_dsatur_vertex(g)

    return colors
    

def paint_vertex(v, color_list):
    ordered_colors = sorted(color_list) # in order to find the color with minimum use

    neighbours_colors = [u.color for u in v.neighbours if u.color != None]

    for color in ordered_colors:
        #print("Checking color", color.id)
        if color not in neighbours_colors:
            v.color = color
            color.count += 1
            return

    #if len(ordered_colors) > 0:
    #    print(type(ordered_colors[0]))
    

    #print(set(ordered_colors))
    if len(color_list) < 3:
        new_color = Color()
        v.color = new_color
        new_color.count += 1
        color_list.append(new_color)
    else:
        dictionary = {}
        minimum_count, minimum_color = inf, None
        for u in v.neighbours:
            if u.color != None:
                if u.color.id in dictionary.keys():
                    dictionary[u.color.id][0] += 1
                else:
                    dictionary[u.color.id] = [1, u.color]
                

        for key,val in dictionary.items():
            if val[0] < minimum_count:
                minimum_count = val[0]
                minimum_color = val[1]

        minimum_color.count += 1
        v.color = minimum_color

def get_next_dsatur_vertex(g):
    unpainted_vertexes = [v for v in g.vertex_list if v.color == None]

    if len(unpainted_vertexes) == 0:
        return None

    unpainted_vertexes.sort(key = lambda x: x.saturation)

    max_saturation = unpainted_vertexes[-1]

    same_saturation_vertexes = [x for x in unpainted_vertexes if x.saturation == max_saturation.saturation]

    if len(same_saturation_vertexes) > 1:
        same_saturation_vertexes.sort()

        max_degree = same_saturation_vertexes[-1]

        same_degree_vertexes = [x for x in same_saturation_vertexes if x.get_degree() == max_degree.get_degree()]

        if len(same_degree_vertexes) > 1:
            same_degree_vertexes.sort(key = lambda x: x.id)

            same_degree_vertexes[0]
            return same_degree_vertexes[0]

        else:
            return max_degree
    else:
        return max_saturation

def print_vertex_list(v_list):
    for v in v_list:
        print(v.id, ": ", end = "")
        for u in v.neighbours:
            print(u.id, end = " ")
        print()

    for v in v_list:
        print(str(v))


def RunDSaturAlgo(adjacency_list, available_colors):
    print("Dsatur module is being called")

    g = Graph([])

    for c in available_colors:
        Color.color_names.append(c)

    for v in adjacency_list.keys():    # [id, [list]]
        vert = Vertex(v)
        g.vertex_list.append(vert)

    for v in g.vertex_list:
        neighbours = adjacency_list[v.id]
        for uid in neighbours:
            for u in g.vertex_list:
                if u.id == uid:
                    Graph.add_edges(v,u)
    
    min_degree, max_degree, medium_degree, sd_degree = g.get_statistics()

    colors = Dsatur(g)

    print("Total colors: ", len(colors))
    print("Edges: ", sum([x.get_degree() for x in g.vertex_list])/2)
    print("Vertexes: ", len(g.vertex_list), "\n")  
    #print_vertex_list(g.vertex_list)

    result_dictionary = {}
    for vert in g.vertex_list:
        result_dictionary[vert.id] = vert.color.name

    return result_dictionary